# EDA for Healthcare in under 30 minutes :)

🔴 Follow this video for the code walkthrough: (Link to be uploaded)

🔴 Download the code from here: https://github.com/pik1989/EDAforHealthcare/**
